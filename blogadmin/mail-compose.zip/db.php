<?php
$con=mysqli_connect('localhost','root','','fee');
if(!$con)
{
	die('error'.mysqli_connect_error());
}
?>