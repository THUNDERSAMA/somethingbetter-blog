<?php
session_start();
$_SESSION['login']="";
$_SESSION['level']="";
$_SESSION['name']="";
//session_destroy();
header("Location:index.html");
?>