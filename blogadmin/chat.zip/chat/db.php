<?php
$con=mysqli_connect('localhost','root','','blog');
if(!$con)
{
	die('error'.mysqli_connect_error());
}
?>